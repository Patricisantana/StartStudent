package com.capgemini.Start.Students;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartStudentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StartStudentsApplication.class, args);
	}

}
